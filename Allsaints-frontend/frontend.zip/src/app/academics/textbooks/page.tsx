import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Textbooks Declaration & List | All Saints Public School, Adoor",
  description:
    "Official CBSE declaration of textbooks by Manager and Principal, and prescribed textbook list 2024-'25 for All Saints Public School, Adoor.",
};

const TEXTBOOK_SCANS = [
  {
    src: "/images/school_content/1773902398-208050332469bb9a3e66d0a_textbook.jpg",
    title: "Official Prescribed Textbooks Declaration – Part 1",
  },
  {
    src: "/images/school_content/1773902398-112296775169bb9a3e65f6c_textbok.jpg",
    title: "Official Prescribed Textbooks Declaration – Part 2",
  },
  {
    src: "/images/school_content/1773902398-85429481369bb9a3e64c21_text.jpg",
    title: "Official Prescribed Textbooks Declaration – Part 3",
  },
];

export default function TextbooksPage() {
  return (
    <div className="section-pad container-custom font-sans">
      
      {/* ─── Breadcrumb ─────────────────────────────────────────────────── */}
      <nav className="mb-4 text-xs font-medium text-slate-500 flex items-center gap-2">
        <Link href="/" className="hover:text-[#0875C9] transition-colors">
          Home
        </Link>
        <span>&rsaquo;</span>
        <span className="text-slate-400">Academics</span>
        <span>&rsaquo;</span>
        <span className="text-[#0875C9] font-bold">Textbooks</span>
      </nav>

      {/* ─── Top Header Banner in Primary Blue Shade ───────────────── */}
      <div className="bg-[#0875C9] text-white text-center py-4 px-6 rounded-2xl mb-8 shadow-sm">
        <h1 className="text-2xl sm:text-3xl md:text-4xl font-serif font-black uppercase tracking-wider text-white">
          TEXTBOOKS
        </h1>
        <p className="text-sm sm:text-base font-serif font-bold text-[#FFB900] mt-1 uppercase tracking-wider">
          CBSE BYE-LAWS COMPLIANCE &amp; DECLARATION
        </p>
      </div>

      <div className="max-w-5xl mx-auto">
        
        {/* ─── Declarations Section with Download Option ─────────────────── */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          
          {/* Declaration of Textbook by Manager */}
          <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-[#D8EAF8] flex flex-col justify-between hover:shadow-md transition-shadow">
            <div className="space-y-3 mb-6">
              <div className="inline-flex items-center gap-2 bg-[#EAF6FF] border border-[#D8EAF8] px-3 py-1 rounded-full text-xs font-bold text-[#0875C9]">
                Statutory Compliance
              </div>
              <h2 className="text-xl sm:text-2xl font-serif font-black text-[#092F78]">
                Declaration of Textbook by Manager
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-sans">
                Official statutory declaration executed by the School Manager certifying scrutiny and compliance with <strong>Rule 2.4.7 (b) of the CBSE Affiliation Bye-Laws</strong>.
              </p>
            </div>
            <div>
              <a
                href="/documents/declaration-of-textbook-manager.pdf"
                target="_blank"
                rel="noopener noreferrer"
                download="Declaration-of-Textbook-Manager.pdf"
                className="inline-flex items-center justify-center bg-[#0875C9] hover:bg-[#0066B5] text-white px-7 py-3 rounded-full text-xs font-bold transition-all shadow-md hover:shadow-lg whitespace-nowrap cursor-pointer"
              >
                <span>Download PDF</span>
              </a>
            </div>
          </div>

          {/* Declaration of Textbook by principal */}
          <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-[#D8EAF8] flex flex-col justify-between hover:shadow-md transition-shadow">
            <div className="space-y-3 mb-6">
              <div className="inline-flex items-center gap-2 bg-[#EAF6FF] border border-[#D8EAF8] px-3 py-1 rounded-full text-xs font-bold text-[#0875C9]">
                Statutory Compliance
              </div>
              <h2 className="text-xl sm:text-2xl font-serif font-black text-[#092F78]">
                Declaration of Textbook by principal
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-sans">
                Official statutory declaration executed by the Principal certifying scrutiny and compliance with <strong>Rule 2.4.7 (b) of the CBSE Affiliation Bye-Laws</strong>.
              </p>
            </div>
            <div>
              <a
                href="/documents/declaration-of-textbook-principal.pdf"
                target="_blank"
                rel="noopener noreferrer"
                download="Declaration-of-Textbook-Principal.pdf"
                className="inline-flex items-center justify-center bg-[#0875C9] hover:bg-[#0066B5] text-white px-7 py-3 rounded-full text-xs font-bold transition-all shadow-md hover:shadow-lg whitespace-nowrap cursor-pointer"
              >
                <span>Download PDF</span>
              </a>
            </div>
          </div>

        </div>

        {/* ─── Joint Declaration Context ─────────────────────────────────── */}
        <div className="bg-[#F4FAFF] border border-[#D8EAF8] rounded-3xl p-6 sm:p-8 mb-12 shadow-xs">
          <h3 className="text-lg sm:text-xl font-serif font-black text-[#092F78] mb-3">
            Joint Declaration by Manager &amp; Principal
          </h3>
          <div className="space-y-3 text-xs sm:text-sm text-slate-700 leading-relaxed font-sans">
            <p>
              In strict compliance with <strong>Rule 2.4.7 (b) of the CBSE Affiliation Bye-Laws</strong>, we hereby declare and certify that we have thoroughly scrutinized the contents of all textbooks prescribed by the school for all classes from Kindergarten up to Class XII.
            </p>
            <p>
              The school primarily prescribes <strong>NCERT publications</strong> for all secondary and senior secondary classes. The supplementary textbooks and early foundational readers from private publishers have been carefully vetted and do not contain any objectionable, communal, derogatory, or anti-constitutional material that hurts the feelings of any class, community, gender, or religious group in society.
            </p>
            <p>
              The management and the school administration assume complete statutory responsibility for the books prescribed.
            </p>
          </div>
        </div>

        {/* ─── List of Textbook 2024-'25 Section ───────────────────────────── */}
        <div className="mb-12">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 mb-8 gap-4">
            <div>
              <h2 className="text-2xl sm:text-3xl font-serif font-black text-[#092F78]">
                List of Textbook 2024-&apos;25
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 mt-1">
                Prescribed textbook list for the academic year 2024-&apos;25 across all classes.
              </p>
            </div>
            <a
              href="/documents/textbooks-declaration.pdf"
              target="_blank"
              rel="noopener noreferrer"
              download="List-of-Textbooks-2024-25.pdf"
              className="inline-flex items-center justify-center bg-[#0875C9] hover:bg-[#0066B5] text-white px-7 py-3 rounded-full text-xs font-bold transition-all shadow-md hover:shadow-lg whitespace-nowrap cursor-pointer self-start sm:self-auto"
            >
              <span>Download PDF</span>
            </a>
          </div>

          {/* Scanned Official Textbook Lists */}
          <div className="space-y-10">
            {TEXTBOOK_SCANS.map((item, idx) => (
              <div
                key={item.src}
                className="bg-white border-2 border-[#D8EAF8] rounded-3xl p-4 sm:p-6 shadow-sm overflow-hidden"
              >
                <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
                  <h3 className="font-serif font-bold text-base text-[#092F78] flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-[#EAF6FF] text-[#0875C9] border border-[#D8EAF8] flex items-center justify-center text-xs font-black">
                      {idx + 1}
                    </span>
                    <span>{item.title}</span>
                  </h3>
                  <a
                    href={item.src}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-[#0875C9] font-bold hover:underline"
                  >
                    View Full Size &rarr;
                  </a>
                </div>

                <div className="relative w-full h-[650px] sm:h-[850px] rounded-2xl overflow-hidden bg-slate-50 border border-slate-100">
                  <Image
                    src={item.src}
                    alt={item.title}
                    fill
                    className="object-contain"
                    priority={idx === 0}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
}
