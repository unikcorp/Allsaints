"use client";

import { useState } from "react";
import Link from "next/link";
import { SCHOOL_INFO } from "@/constants";

export default function AdmissionEnquiryPage() {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="section-pad container-custom font-sans">
      {/* ─── Breadcrumb / Eyebrow ────────────────────────────────────────── */}
      <div className="mb-2">
        <span className="text-xs font-serif font-bold uppercase tracking-widest text-[#0875C9] inline-flex items-center gap-1.5 bg-[#EAF6FF] px-3.5 py-1 rounded-full border border-[#D8EAF8]">
          <span className="w-1.5 h-1.5 rounded-full bg-[#FFB900]" />
          Admissions Open 2026–2027 · Play Class to Class XII
        </span>
      </div>

      <h1 className="text-3xl sm:text-4xl md:text-5xl font-serif font-bold text-[#092F78] mb-3 tracking-tight">
        Admission Enquiry Form
      </h1>
      <div className="w-20 h-1 bg-gradient-to-r from-[#0875C9] to-[#FFB900] rounded-full mb-8" />

      <div className="grid lg:grid-cols-12 gap-8 items-start">
        {/* Left Information Card */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-gradient-to-br from-white via-[#F4FAFF] to-[#EAF6FF] border border-[#D8EAF8] rounded-3xl p-6 sm:p-8 shadow-sm">
            <h2 className="font-serif font-bold text-xl text-[#092F78] mb-3">
              Why Choose All Saints Public School?
            </h2>
            <ul className="space-y-3 text-xs sm:text-sm text-slate-700">
              <li className="flex items-start gap-2.5">
                <span className="text-[#0875C9] font-bold text-base leading-none">✓</span>
                <span><strong>100% CBSE Success Record:</strong> Exemplary board results with distinctions across Science &amp; Commerce.</span>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="text-[#0875C9] font-bold text-base leading-none">✓</span>
                <span><strong>10-Acre Eco Campus:</strong> Spacious playground, herbal organic garden, smart digital classes &amp; modern labs.</span>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="text-[#0875C9] font-bold text-base leading-none">✓</span>
                <span><strong>14 Bus Conveyance Routes:</strong> GPS-tracked fleet covering Adoor, Pandalam, Kodumon, and surrounding taluks.</span>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="text-[#0875C9] font-bold text-base leading-none">✓</span>
                <span><strong>Holistic Co-Curriculars:</strong> Karate, Yoga, Spoken English (LUSE), Music Carnival, and Student Parliament.</span>
              </li>
            </ul>
          </div>

          <div className="bg-[#EAF6FF] border border-[#D8EAF8] rounded-2xl p-6 text-xs text-slate-700">
            <h3 className="font-serif font-bold text-sm text-[#092F78] mb-2">
              Admissions Helpline:
            </h3>
            <p className="mb-1">
              📞 <strong>Phone:</strong> {SCHOOL_INFO.phone[0]}, {SCHOOL_INFO.phone[1]}
            </p>
            <p className="mb-1">
              ✉️ <strong>Email:</strong> {SCHOOL_INFO.email}
            </p>
            <p>
              📍 <strong>Campus:</strong> Pannivizha P.O., Adoor, Pathanamthitta - 691523
            </p>
          </div>
        </div>

        {/* Right Form Card */}
        <div className="lg:col-span-7 bg-white border-2 border-[#D8EAF8] rounded-3xl p-6 sm:p-8 shadow-sm">
          {submitted ? (
            <div className="text-center py-12">
              <div className="w-16 h-16 mx-auto rounded-full bg-[#EAF6FF] text-[#0875C9] border-2 border-[#0875C9] flex items-center justify-center text-3xl mb-4">
                ✓
              </div>
              <h2 className="font-serif font-bold text-2xl text-[#092F78] mb-2">
                Enquiry Submitted Successfully!
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 max-w-md mx-auto mb-6 leading-relaxed">
                Thank you for your interest in All Saints Public School, Adoor. Our admissions coordinator will reach out to you within 24 hours to schedule a campus visit and guide you through the enrollment process.
              </p>
              <div className="flex justify-center gap-3">
                <Link
                  href="/"
                  className="bg-[#0875C9] hover:bg-[#0066B5] text-white px-6 py-2.5 rounded-full text-xs font-bold transition-all shadow-sm"
                >
                  Return to Home
                </Link>
                <Link
                  href="/admissions/fees"
                  className="border border-[#0875C9] text-[#0875C9] hover:bg-[#EAF6FF] px-6 py-2.5 rounded-full text-xs font-bold transition-all"
                >
                  View Fee Structure
                </Link>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <h2 className="font-serif font-bold text-xl text-[#092F78] mb-1">
                Student Admission Enquiry Form
              </h2>
              <p className="text-xs text-slate-500 mb-4">
                Please provide accurate details so our academic counselor can assist you.
              </p>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#092F78] mb-1">
                  Student&apos;s Full Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Aaron George"
                  className="w-full px-4 py-2.5 border border-slate-300 rounded-xl text-xs font-sans focus:outline-none focus:border-[#0875C9] focus:ring-1 focus:ring-[#0875C9]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#092F78] mb-1">
                    Grade Applying For *
                  </label>
                  <select
                    required
                    className="w-full px-4 py-2.5 border border-slate-300 rounded-xl text-xs font-sans focus:outline-none focus:border-[#0875C9] focus:ring-1 focus:ring-[#0875C9] bg-white text-slate-700"
                  >
                    <option value="">Select Class</option>
                    <option value="Play Class">Play Class</option>
                    <option value="LKG">LKG (Lower Kindergarten)</option>
                    <option value="UKG">UKG (Upper Kindergarten)</option>
                    <option value="Class 1">Class 1</option>
                    <option value="Class 2">Class 2</option>
                    <option value="Class 3">Class 3</option>
                    <option value="Class 4">Class 4</option>
                    <option value="Class 5">Class 5</option>
                    <option value="Class 6">Class 6</option>
                    <option value="Class 7">Class 7</option>
                    <option value="Class 8">Class 8</option>
                    <option value="Class 9">Class 9</option>
                    <option value="Class 11 Science (PCMB)">Class 11 - Science (Bio-Maths)</option>
                    <option value="Class 11 Science (PCMC)">Class 11 - Science (Computer)</option>
                    <option value="Class 11 Commerce">Class 11 - Commerce Stream</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#092F78] mb-1">
                    Date of Birth *
                  </label>
                  <input
                    type="date"
                    required
                    className="w-full px-4 py-2.5 border border-slate-300 rounded-xl text-xs font-sans focus:outline-none focus:border-[#0875C9] focus:ring-1 focus:ring-[#0875C9]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#092F78] mb-1">
                    Parent / Guardian Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Father / Mother / Guardian"
                    className="w-full px-4 py-2.5 border border-slate-300 rounded-xl text-xs font-sans focus:outline-none focus:border-[#0875C9] focus:ring-1 focus:ring-[#0875C9]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#092F78] mb-1">
                    Contact Mobile Number *
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="10-digit phone number"
                    className="w-full px-4 py-2.5 border border-slate-300 rounded-xl text-xs font-sans focus:outline-none focus:border-[#0875C9] focus:ring-1 focus:ring-[#0875C9]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#092F78] mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    placeholder="email@example.com"
                    className="w-full px-4 py-2.5 border border-slate-300 rounded-xl text-xs font-sans focus:outline-none focus:border-[#0875C9] focus:ring-1 focus:ring-[#0875C9]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#092F78] mb-1">
                    Current Location / Residence Area
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Adoor, Pandalam, Kodumon"
                    className="w-full px-4 py-2.5 border border-slate-300 rounded-xl text-xs font-sans focus:outline-none focus:border-[#0875C9] focus:ring-1 focus:ring-[#0875C9]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#092F78] mb-1">
                  Do you require School Bus Conveyance?
                </label>
                <select className="w-full px-4 py-2.5 border border-slate-300 rounded-xl text-xs font-sans focus:outline-none focus:border-[#0875C9] focus:ring-1 focus:ring-[#0875C9] bg-white text-slate-700">
                  <option value="yes">Yes, require school conveyance</option>
                  <option value="no">No, will arrange own transport</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#092F78] mb-1">
                  Questions or Remarks
                </label>
                <textarea
                  rows={3}
                  placeholder="Previous school details, special achievements, or any questions..."
                  className="w-full px-4 py-2.5 border border-slate-300 rounded-xl text-xs font-sans focus:outline-none focus:border-[#0875C9] focus:ring-1 focus:ring-[#0875C9]"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-[#0875C9] hover:bg-[#0066B5] text-white py-3.5 rounded-full font-serif font-bold text-xs uppercase tracking-wider shadow-md hover:shadow-lg transition-all cursor-pointer"
              >
                Submit Admission Enquiry &rarr;
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
