"use client";

import { useState, useEffect, useCallback } from "react";
import Image from "next/image";
import Link from "next/link";
import {
  EditableNews,
  DEFAULT_NEWS,
  getStoredNews,
} from "@/utils/adminStorage";
import { apiGetNews } from "@/utils/apiService";

interface CampusSlide {
  image: string;
  title: string;
  caption: string;
}

const HERO_CAMPUS_SLIDES: CampusSlide[] = [
  {
    image: "/images/home_slider/slider-1.jpg",
    title: "All Saints Public School Campus",
    caption: "CBSE Affiliated (930501) · LKG to Class XII · Pannivizha, Adoor",
  },
  {
    image: "/images/home_slider/slider-2.jpg",
    title: "Eco-Friendly Lush Green Grounds",
    caption: "Spacious Campus, Play Arenas & High-Tech Smart Classrooms",
  },
  {
    image: "/images/home_slider/slider-3.jpg",
    title: "Nurturing Mind, Body & Spirit",
    caption: "To Create Creators · Holistic Academic & Moral Excellence",
  },
  {
    image: "/images/school_content/1773902398-126526803569bb9a3e60523_infra.jpg",
    title: "State-of-the-Art Infrastructure",
    caption: "Future-Ready Learning with 100% CBSE Success Record",
  },
];

export default function Hero() {
  const [campusSlide, setCampusSlide] = useState(0);
  const [newsSlide, setNewsSlide] = useState(0);
  const [isCampusPaused, setIsCampusPaused] = useState(false);
  const [isNewsPaused, setIsNewsPaused] = useState(false);
  const [newsList, setNewsList] = useState<EditableNews[]>(DEFAULT_NEWS);

  useEffect(() => {
    setNewsList(getStoredNews());
    apiGetNews().then((data) => {
      if (data && Array.isArray(data) && data.length > 0) {
        const mapped: EditableNews[] = data.map((n: any) => ({
          id: String(n.id),
          title: n.title,
          date: n.publish_date,
          category: n.category,
          excerpt: n.excerpt,
          image: n.image_url || "",
          videoUrl: n.video_url || "",
          isFeatured: Boolean(n.is_featured),
          published: Boolean(n.is_published),
        }));
        setNewsList(mapped);
      }
    });
  }, []);

  // Campus background slider handlers
  const nextCampusSlide = useCallback(() => {
    setCampusSlide((prev) => (prev + 1) % HERO_CAMPUS_SLIDES.length);
  }, []);

  const prevCampusSlide = useCallback(() => {
    setCampusSlide((prev) => (prev - 1 + HERO_CAMPUS_SLIDES.length) % HERO_CAMPUS_SLIDES.length);
  }, []);

  // Daily News slider handlers
  const nextNewsSlide = useCallback(() => {
    setNewsSlide((prev) => (prev + 1) % (newsList.length || 1));
  }, [newsList.length]);

  const prevNewsSlide = useCallback(() => {
    setNewsSlide((prev) => (prev - 1 + (newsList.length || 1)) % (newsList.length || 1));
  }, [newsList.length]);

  // Automatic scrolling for Campus Background
  useEffect(() => {
    if (isCampusPaused) return;
    const interval = setInterval(() => {
      nextCampusSlide();
    }, 6000);
    return () => clearInterval(interval);
  }, [nextCampusSlide, isCampusPaused]);

  // Automatic scrolling for Daily News
  useEffect(() => {
    if (isNewsPaused) return;
    const interval = setInterval(() => {
      nextNewsSlide();
    }, 4500);
    return () => clearInterval(interval);
  }, [nextNewsSlide, isNewsPaused]);

  // Swipe / Drag support for horizontal movement inside news card
  const [touchStartX, setTouchStartX] = useState<number | null>(null);
  const [mouseStartX, setMouseStartX] = useState<number | null>(null);

  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStartX(e.targetTouches[0].clientX);
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartX === null) return;
    const diff = touchStartX - e.changedTouches[0].clientX;
    if (diff > 40) {
      nextNewsSlide();
    } else if (diff < -40) {
      prevNewsSlide();
    }
    setTouchStartX(null);
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    setMouseStartX(e.clientX);
  };

  const handleMouseUp = (e: React.MouseEvent) => {
    if (mouseStartX === null) return;
    const diff = mouseStartX - e.clientX;
    if (diff > 40) {
      nextNewsSlide();
    } else if (diff < -40) {
      prevNewsSlide();
    }
    setMouseStartX(null);
  };

  return (
    <section
      className="relative w-full overflow-hidden bg-[#F0F7FF] border-b border-[#D8EAF8] min-h-[540px] sm:min-h-[580px] lg:min-h-[600px] xl:min-h-[640px] flex items-center"
      onMouseEnter={() => setIsCampusPaused(true)}
      onMouseLeave={() => setIsCampusPaused(false)}
      aria-label="All Saints Public School Campus Showcase"
    >
      {/* ─── 1. FULL PANORAMIC CAMPUS BACKGROUND SLIDER ──────────────────── */}
      <div
        className="absolute inset-0 flex h-full w-full transition-transform duration-700 ease-in-out z-0"
        style={{ transform: `translateX(-${campusSlide * 100}%)` }}
      >
        {HERO_CAMPUS_SLIDES.map((slide, index) => (
          <div key={slide.image} className="relative h-full w-full flex-shrink-0">
            <Image
              src={slide.image}
              alt={slide.title}
              fill
              priority={index === 0}
              unoptimized
              quality={100}
              className="object-cover object-right sm:object-[75%_center] lg:object-right select-none"
              sizes="100vw"
            />
          </div>
        ))}
      </div>

      {/* ─── 2. CRYSTAL-CLEAR SOFT LEFT GRADIENT (Zero Blur Over Building) ─ */}
      {/* Confined strictly behind the left text so the school building & lawn stay 100% razor-sharp */}
      <div className="absolute inset-0 bg-gradient-to-r from-[#F0F7FF] via-[#F0F7FF]/90 via-26% md:via-34% to-transparent z-1 pointer-events-none" />

      {/* ─── 3. FOREGROUND CONTENT: TWO-COLUMN PANORAMIC LAYOUT ───────────── */}
      <div className="relative z-10 w-full max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-14 xl:px-16 py-12 sm:py-14 lg:py-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-8 items-center justify-between">
          
          {/* ─── LEFT COLUMN: WELCOME & SCHOOL IDENTITY ───────────────────── */}
          <div className="lg:col-span-7 xl:col-span-7 max-w-2xl">
            {/* Elegant "Welcome to" with Golden Underline Swoosh */}
            <div className="inline-block mb-1 sm:mb-2">
              <span className="font-['Dancing_Script',cursive,serif] italic text-3xl sm:text-4xl md:text-[42px] lg:text-[46px] text-[#0875C9] font-bold tracking-wide leading-none">
                Welcome to
              </span>
              <svg
                className="w-28 sm:w-36 md:w-44 h-2.5 sm:h-3 text-[#FFB900] mt-0.5 sm:mt-1"
                viewBox="0 0 160 12"
                fill="none"
              >
                <path
                  d="M2 8C50 2 110 2 158 8"
                  stroke="currentColor"
                  strokeWidth="3.5"
                  strokeLinecap="round"
                />
              </svg>
            </div>

            {/* School Name Headline (Crisp Navy Serif) */}
            <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-[60px] xl:text-[66px] font-serif font-black text-[#092F78] tracking-tight leading-[1.04] mb-3 sm:mb-4">
              All Saints Public<br className="hidden sm:inline" /> School
            </h1>

            {/* Motto with Golden Dots: Learn • Grow • Excel */}
            <div className="flex items-center gap-3 text-lg sm:text-2xl lg:text-[25px] font-serif font-bold text-[#092F78] mb-3 sm:mb-4">
              <span>Learn</span>
              <span className="w-2.5 h-2.5 rounded-full bg-[#FFB900]" />
              <span>Grow</span>
              <span className="w-2.5 h-2.5 rounded-full bg-[#FFB900]" />
              <span>Excel</span>
            </div>

            {/* Subtext Description */}
            <p className="text-xs sm:text-sm md:text-[15px] lg:text-base text-slate-700 font-sans font-medium mb-6 max-w-lg leading-relaxed">
              Nurturing young minds for a brighter tomorrow through moral excellence, holistic academics, and innovative creativity.
            </p>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-3.5 pt-1">
              <Link
                href="/admissions/enquiry"
                className="inline-flex items-center justify-center gap-2 bg-[#0875C9] hover:bg-[#0066B5] text-white px-7 sm:px-8 py-3 sm:py-3.5 rounded-full text-xs sm:text-sm font-sans font-bold tracking-wide shadow-md hover:shadow-lg transition-all hover:scale-105"
              >
                <span>Admission Enquiry</span>
                <span className="text-base">&rarr;</span>
              </Link>

              <Link
                href="/gallery"
                className="inline-flex items-center justify-center gap-2 bg-white hover:bg-[#EAF6FF] text-[#092F78] hover:text-[#0875C9] border-2 border-[#0875C9] px-6 sm:px-7 py-3 sm:py-3.5 rounded-full text-xs sm:text-sm font-sans font-bold tracking-wide shadow-xs hover:shadow-md transition-all hover:scale-105"
              >
                <span className="text-xs text-[#0875C9]">▶</span>
                <span>Watch Our School</span>
              </Link>
            </div>
          </div>

          {/* ─── RIGHT COLUMN: FLOATING DAILY NEWS CARD ───────────────────── */}
          <div className="lg:col-span-5 xl:col-span-5 flex justify-start lg:justify-end items-end lg:self-end mt-4 lg:mt-0">
            <div
              className="w-full max-w-md lg:max-w-[420px] bg-white rounded-3xl shadow-2xl border border-slate-100 p-5 sm:p-6 transition-all relative overflow-hidden select-none cursor-grab active:cursor-grabbing group/card"
              onMouseEnter={() => setIsNewsPaused(true)}
              onMouseLeave={() => setIsNewsPaused(false)}
              onTouchStart={handleTouchStart}
              onTouchEnd={handleTouchEnd}
              onMouseDown={handleMouseDown}
              onMouseUp={handleMouseUp}
              aria-label="Daily News Bulletin"
            >
              {/* Header Row: Megaphone Badge & All News Link */}
              <div className="flex items-center justify-between gap-3 mb-3">
                <div className="inline-flex items-center gap-1.5 bg-[#092F78] text-white text-[11px] font-sans font-black px-3.5 py-1.5 rounded-full uppercase tracking-wider shadow-xs">
                  <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                    <path d="M21 4.25a.75.75 0 00-.75-.75H17a1 1 0 00-1 1v1.5a1 1 0 001 1h.5v6.5h-.5a1 1 0 00-1 1v1.5a1 1 0 001 1h3.25a.75.75 0 00.75-.75V4.25zM14 6H7.83a3 3 0 00-2.12.88L3.29 9.3A1 1 0 003 10v4a1 1 0 00.29.71l2.42 2.41A3 3 0 007.83 18H14V6z" />
                  </svg>
                  <span>DAILY NEWS</span>
                </div>

                <Link
                  href="/news"
                  className="inline-flex items-center gap-1 text-xs font-sans font-bold text-[#092F78] hover:text-[#0875C9] transition-colors"
                >
                  <span>All News</span>
                  <span className="text-sm font-bold">&rarr;</span>
                </Link>
              </div>

              {/* Slider Track (Moves horizontally inside card with 100% single-item viewport) */}
              <div className="w-full overflow-hidden">
                <div
                  className="flex transition-transform duration-500 ease-in-out"
                  style={{
                    width: `${(newsList.length || 1) * 100}%`,
                    transform: `translateX(-${(newsSlide * 100) / (newsList.length || 1)}%)`,
                  }}
                >
                {newsList.map((item, index) => {
                  let displayDate = item.date || "20-05-2026";
                  if (item.date) {
                    try {
                      const d = new Date(item.date);
                      if (!isNaN(d.getTime())) {
                        const day = String(d.getDate()).padStart(2, "0");
                        const month = String(d.getMonth() + 1).padStart(2, "0");
                        const year = d.getFullYear();
                        displayDate = `${day}-${month}-${year}`;
                      }
                    } catch {
                      const rawDate = item.date.includes("T") ? item.date.split("T")[0] : item.date;
                      displayDate = rawDate;
                    }
                  }
                  return (
                    <div key={item.id || index} className="flex-shrink-0" style={{ width: `${100 / (newsList.length || 1)}%` }}>
                      {/* Date Badge: 🗓️ 20-05-2026 */}
                      <div className="flex items-center gap-2 mb-2">
                        <span className="inline-flex items-center gap-1.5 text-xs text-[#0875C9] font-sans font-bold bg-[#EAF4FF] px-2.5 py-1 rounded-md">
                          <span>🗓️</span>
                          <span>{displayDate}</span>
                        </span>
                        {item.category && (
                          <span className="text-[11px] font-sans font-semibold text-slate-500 uppercase tracking-wide">
                            {item.category}
                          </span>
                        )}
                      </div>

                      {/* Title (Bold Navy Heading) */}
                      <h3 className="text-[#092F78] font-sans font-bold text-base sm:text-lg leading-snug tracking-tight mb-1.5 line-clamp-2">
                        <Link href="/news" className="hover:text-[#0875C9] transition-colors">
                          {item.title}
                        </Link>
                      </h3>

                      {/* Excerpt */}
                      <p className="text-slate-600 font-sans text-xs sm:text-[13px] leading-relaxed line-clamp-2 font-normal">
                        {item.excerpt}
                      </p>
                    </div>
                  );
                })}
              </div>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* ─── 4. BOTTOM CENTER SLIDE DOTS (Matches Reference Design) ───────── */}
      <div className="absolute bottom-4 sm:bottom-5 left-1/2 -translate-x-1/2 z-20 flex items-center gap-1.5 bg-black/10 backdrop-blur-xs px-2.5 py-1 rounded-full">
        {HERO_CAMPUS_SLIDES.map((_, i) => (
          <button
            key={i}
            onClick={() => setCampusSlide(i)}
            aria-label={`Campus slide ${i + 1}`}
            className={`h-2 rounded-full transition-all duration-300 cursor-pointer ${
              i === campusSlide
                ? "w-6 bg-[#092F78]"
                : "w-2 bg-white/90 hover:bg-white shadow-xs"
            }`}
          />
        ))}
      </div>
    </section>
  );
}
