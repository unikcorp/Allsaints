import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  devIndicators: false,
  images: {
    qualities: [75, 100],
    remotePatterns: [
      {
        protocol: "https",
        hostname: "res.cloudinary.com",
      },
      {
        protocol: "http",
        hostname: "localhost",
        port: "5000",
      },
    ],
  },
  async rewrites() {
    return [
      {
        source: "/uploads/:path*",
        destination: "http://localhost:5000/uploads/:path*",
      },
    ];
  },
  async redirects() {
    return [
      {
        source: "/frontend",
        destination: "/",
        permanent: false,
      },
      {
        source: "/online_admission",
        destination: "/admissions/apply",
        permanent: false,
      },
      {
        source: "/welcome/checkadmissionstatus",
        destination: "/admissions/apply",
        permanent: false,
      },
      {
        source: "/page/annual-report",
        destination: "/academics/annual-report",
        permanent: false,
      },
      {
        source: "/site/login",
        destination: "/login",
        permanent: false,
      },
      {
        source: "/admin/login",
        destination: "/login",
        permanent: false,
      },
    ];
  },
};

export default nextConfig;
