const fs = require('fs');
const path = require('path');

function createPdf(title, subtitle, sections) {
  // Escape parentheses in strings
  const esc = (str) => str.replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)');

  let content = `BT\n/F1 16 Tf\n50 760 Td\n(${esc(title)}) Tj\nET\n`;
  content += `BT\n/F2 10 Tf\n50 742 Td\n(${esc(subtitle)}) Tj\nET\n`;
  content += `BT\n/F2 9 Tf\n50 726 Td\n(Generated for All Saints Public School, Adoor, Pathanamthitta - CBSE Affiliation: 930773) Tj\nET\n`;

  // Draw a horizontal line across the page
  content += `0.5 w\n50 715 m\n545 715 l\nS\n`;

  let y = 690;
  for (const s of sections) {
    if (y < 80) break; // stay within page bounds
    content += `BT\n/F1 12 Tf\n50 ${y} Td\n(${esc(s.heading)}) Tj\nET\n`;
    y -= 18;
    for (const l of s.lines) {
      if (y < 60) break;
      content += `BT\n/F2 9 Tf\n60 ${y} Td\n(${esc(l)}) Tj\nET\n`;
      y -= 14;
    }
    y -= 12;
  }

  // Footer
  content += `0.5 w\n50 45 m\n545 45 l\nS\n`;
  content += `BT\n/F2 8 Tf\n50 32 Td\n(Official Statutory Record - All Saints Public School, Pannivizha, Adoor, Kerala 691523 | allsaintsschool501@gmail.com) Tj\nET\n`;

  const stream = content;
  const objects = [];

  objects.push('1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj');
  objects.push('2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj');
  objects.push('3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents 4 0 R /Resources << /Font << /F1 5 0 R /F2 6 0 R >> >> >>\nendobj');
  objects.push(`4 0 obj\n<< /Length ${Buffer.byteLength(stream)} >>\nstream\n${stream}\nendstream\nendobj`);
  objects.push('5 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>\nendobj');
  objects.push('6 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj');

  let pdf = '%PDF-1.4\n';
  const xref = [0];

  for (const obj of objects) {
    xref.push(Buffer.byteLength(pdf));
    pdf += obj + '\n';
  }

  const startxref = Buffer.byteLength(pdf);
  pdf += 'xref\n';
  pdf += `0 ${objects.length + 1}\n`;
  pdf += '0000000000 65535 f \n';
  for (let i = 1; i < xref.length; i++) {
    pdf += String(xref[i]).padStart(10, '0') + ' 00000 n \n';
  }

  pdf += 'trailer\n';
  pdf += `<< /Size ${objects.length + 1} /Root 1 0 R >>\n`;
  pdf += 'startxref\n';
  pdf += `${startxref}\n`;
  pdf += '%%EOF\n';

  return Buffer.from(pdf, 'binary');
}

const outDir = 'C:\\AllSaintswebsite\\frontend\\public\\documents';
if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

const DOCUMENTS = [
  {
    fileName: 'cbse-mandatory-public-disclosure.pdf',
    title: 'ALL SAINTS PUBLIC SCHOOL - MANDATORY PUBLIC DISCLOSURE',
    subtitle: 'CBSE Appendix IX Compliance Document | Affiliation No: 930773 | School Code: 75786',
    sections: [
      {
        heading: 'A. GENERAL INFORMATION',
        lines: [
          '1. Name of the School: ALL SAINTS PUBLIC SCHOOL',
          '2. Affiliation No.: 930773 (Senior Secondary Level)',
          '3. School Code: 75786',
          '4. Complete Address: Pannivizha P.O., Adoor, Pathanamthitta District, Kerala - 691523',
          '5. Principal Name & Qualification: Fr. Thomas Mathew, M.A., B.Ed.',
          '6. School Email: allsaintsschool501@gmail.com',
          '7. Contact Telephone: +91 7356804100, +91 6235522549'
        ]
      },
      {
        heading: 'B. DOCUMENTS AND INFORMATION',
        lines: [
          '1. Copies of Affiliation / Upgradation Letter: Verified and Uploaded',
          '2. Societies / Trust Registration Certificate: Registered under Malankara Catholic Educational Society',
          '3. No Objection Certificate (NOC) by State Govt.: Issued by Govt. of Kerala',
          '4. Recognition Certificate under RTE Act 2009: Granted by General Education Department',
          '5. Building Safety Certificate: Issued by Assistant Engineer LSGD',
          '6. Fire Safety Certificate: Certified by Kerala Fire and Rescue Services',
          '7. Water, Health and Sanitation Certificate: Certified Safe Drinking Water'
        ]
      },
      {
        heading: 'C. RESULT AND ACADEMICS',
        lines: [
          '1. Fee Structure of the School: Fixed annually as per state and board norms',
          '2. Annual Academic Calendar: Implemented April through March',
          '3. List of School Management Committee (SMC): Duly constituted and functional',
          '4. Last 3-Year Board Pass Percentage: 100% CBSE Class X and Class XII'
        ]
      }
    ]
  },
  {
    fileName: 'cbse-affiliation-certificate.pdf',
    title: 'CBSE SENIOR SECONDARY AFFILIATION CERTIFICATE',
    subtitle: 'Central Board of Secondary Education, Shiksha Kendra, Preet Vihar, Delhi',
    sections: [
      {
        heading: 'AFFILIATION DETAILS',
        lines: [
          'Affiliation Number: 930773',
          'School Code: 75786',
          'Affiliation Status: Provisionally Affiliated / Senior Secondary Upgraded',
          'Subject Streams Approved: Science (PCMB, PCMC), Commerce with Informatics, Humanities',
          'Medium of Instruction: English',
          'Administration: The Malankara Catholic Educational Society, Diocese of Pathanamthitta'
        ]
      },
      {
        heading: 'INSTITUTIONAL ENDORSEMENT',
        lines: [
          'Certified that All Saints Public School, Adoor fulfills all prescribed land, infrastructural,',
          'safety, library, laboratory, and qualified teaching faculty criteria stipulated under CBSE Bye-Laws.'
        ]
      }
    ]
  },
  {
    fileName: 'fee-structure-2025-26.pdf',
    title: 'ALL SAINTS PUBLIC SCHOOL - OFFICIAL FEE SCHEDULE 2025-26',
    subtitle: 'Approved by School Management Committee & Board of Governors',
    sections: [
      {
        heading: 'FEE SCHEDULE BY GRADE LEVEL (PER TERM)',
        lines: [
          'Kindergarten (Pre-KG / LKG / UKG): Tuition Fee Rs. 6,800/term | Activity Fee: Rs. 1,200',
          'Primary School (Grades 1 to 5): Tuition Fee Rs. 8,200/term | Computer & Science Lab: Rs. 1,500',
          'Middle School (Grades 6 to 8): Tuition Fee Rs. 9,500/term | Lab & Digital Smart Class: Rs. 1,800',
          'Secondary School (Grades 9 & 10): Tuition Fee Rs. 11,200/term | Board Reg & Special Coaching: Rs. 2,200',
          'Senior Secondary Science (Grades 11 & 12): Tuition Fee Rs. 13,800/term | Lab Practicals: Rs. 3,000',
          'Senior Secondary Commerce / Humanities: Tuition Fee Rs. 12,500/term | IT & Applied Skills: Rs. 2,500'
        ]
      },
      {
        heading: 'PAYMENT POLICIES & CONVEYANCE',
        lines: [
          '1. Fees can be remitted online via School Portal or bank transfer at South Indian Bank.',
          '2. Term 1 due June 15 | Term 2 due October 15 | Term 3 due January 15.',
          '3. Bus conveyance charged based on designated route distance across the 14 service zones.'
        ]
      }
    ]
  },
  {
    fileName: 'academic-calendar-2025-26.pdf',
    title: 'ALL SAINTS PUBLIC SCHOOL - ACADEMIC CALENDAR 2025-26',
    subtitle: 'Curricular, Co-Curricular & Examination Schedule',
    sections: [
      {
        heading: 'TERM SCHEDULE & MAJOR MILESTONES',
        lines: [
          'June 2025: School Reopening, Welcome Assembly, Environment Day Observance',
          'July 2025: Periodic Assessment 1, Investiture Ceremony, Club Formations',
          'August 2025: Independence Day Celebrations, Science & Art Exhibition (AI NEXUS)',
          'September 2025: Onam Celebrations, Teachers Day, Mid-Term Examinations',
          'October 2025: Saintsian Olympics Annual Athletic Meet @ Kodumon Stadium',
          'November 2025: Childrens Day, Youth Festival (ARPEGGIO), Periodic Assessment 2',
          'December 2025: Christmas Celebrations, Winter Break Commences',
          'January 2026: School Reopens, Pre-Board Examination for Classes X & XII, Republic Day',
          'February 2026: SAINTSANTHE Annual Day Celebrations, Model Exams',
          'March 2026: CBSE Board Examinations & Annual Term End Evaluations'
        ]
      }
    ]
  },
  {
    fileName: 'textbooks-declaration.pdf',
    title: 'DECLARATION OF PRESCRIBED TEXTBOOKS 2025-26',
    subtitle: 'In Compliance with CBSE Affiliation Bye-Laws Rule 2.4.7',
    sections: [
      {
        heading: 'DECLARATION',
        lines: [
          'We, the Manager and Principal of All Saints Public School, Adoor, hereby solemnly declare',
          'that the textbooks prescribed for all classes (LKG to Class XII) follow strictly the National',
          'Curriculum Framework (NCF) and NCERT / CBSE publication standards.',
          '',
          'No book contains any objectionable content, gender-biased narratives, or material prejudicial',
          'to societal communal harmony. All private publisher workbooks used in primary stages have been',
          'scrupulously examined and vetted by the internal Academic Quality Council.'
        ]
      }
    ]
  },
  {
    fileName: 'annual-report.pdf',
    title: 'ANNUAL SCHOOL PROGRESS REPORT 2024-25',
    subtitle: 'Comprehensive Institutional Review Presented at SAINTSANTHE',
    sections: [
      {
        heading: 'ACADEMIC EXCELLENCE & ACHIEVEMENTS',
        lines: [
          'CBSE Class XII Pass Percentage: 100% with 84% students securing First Class with Distinction.',
          'CBSE Class X Pass Percentage: 100% with multiple full A1 grade achievements.',
          'Sports & Athletics: Champions at Sahodaya Athletic Meet and District Football Tournament.',
          'Flagship Programs: LUSE, MMC (Maths Master), CuC, and Democratic Students Parliament.',
          'Staff Development: 50+ hours of continuous CBSE professional teacher training completed.'
        ]
      }
    ]
  },
  {
    fileName: 'building-safety-certificate.pdf',
    title: 'BUILDING SAFETY & FITNESS CERTIFICATE',
    subtitle: 'Issued by Local Self Government Department (LSGD)',
    sections: [
      {
        heading: 'INSPECTION & STRUCTURAL AUDIT',
        lines: [
          'Inspection Agency: Assistant Engineer, LSGD Section, Adoor',
          'Campus Classification: Educational Institution Building Occupancy',
          'Structural Framework: Reinforced Cement Concrete (RCC) Framed Construction',
          'Finding: Certified that the structural members, staircases, emergency escape passages,',
          'and roof stability are sound, safe, and fit for academic occupancy in all seasons.'
        ]
      }
    ]
  },
  {
    fileName: 'fire-safety-certificate.pdf',
    title: 'FIRE AND RESCUE SERVICES CERTIFICATE OF APPROVAL',
    subtitle: 'Kerala Fire and Rescue Services Department, Fire Station Adoor',
    sections: [
      {
        heading: 'FIRE PREVENTION & COMBATING AUDIT',
        lines: [
          'Certificate No: KFRS/ADR/2024/CERT-892',
          'Safety Apparatus: Overhead water storage, yard hydrants, ABC powder extinguishers, hose reels',
          'Exit Routes: Dual wide concrete staircases on either wing compliant with NBC standards',
          'Drills: Regular mock evacuation and fire combat trainings conducted for staff and students.'
        ]
      }
    ]
  },
  {
    fileName: 'sanitation-water-certificate.pdf',
    title: 'POTABLE WATER QUALITY & SANITARY FITNESS CERTIFICATE',
    subtitle: 'Community Health Centre & Public Health Laboratory Verification',
    sections: [
      {
        heading: 'HYGIENIC & SANITATION ASSESSMENT',
        lines: [
          'Testing Authority: Public Health Water Testing Laboratory, Pathanamthitta',
          'Bacteriological Quality: Coliform test negative. Safe for drinking.',
          'Chemical Quality: pH, TDS, hardness, and fluorides within BIS 10500 potable limits.',
          'Sanitary Installations: Sufficient, hygienic, and well-ventilated separate washrooms for boys and girls.'
        ]
      }
    ]
  },
  {
    fileName: 'school-prospectus.pdf',
    title: 'ALL SAINTS PUBLIC SCHOOL - INFORMATION PROSPECTUS',
    subtitle: 'Motto: To Create Creators | Affiliated to CBSE, New Delhi',
    sections: [
      {
        heading: 'ABOUT THE INSTITUTION',
        lines: [
          'Established under the celestial patronage of The Malankara Catholic Educational Society.',
          'Located in a pristine 10-acre green campus in Pannivizha, Adoor.',
          'Smart digital digiboard classrooms, automated science & robotic labs, organic farm campus.',
          'Full-fledged athletic facilities: football ground, basketball court, karate, yoga, and athletic tracks.'
        ]
      },
      {
        heading: 'ADMISSION GUIDELINES 2026-27',
        lines: [
          'Admissions open for Playschool, LKG, UKG, and Grades 1 through 11.',
          'Apply directly via the Online Admission Portal at /admissions/apply.',
          'Required documents: Birth Certificate, Transfer Certificate (TC), Report Card, Passport Photos.'
        ]
      }
    ]
  }
];

for (const doc of DOCUMENTS) {
  const filePath = path.join(outDir, doc.fileName);
  const buf = createPdf(doc.title, doc.subtitle, doc.sections);
  fs.writeFileSync(filePath, buf);
  console.log('Created PDF:', doc.fileName, 'Size:', buf.length, 'bytes');
}
console.log('All 10 official PDFs generated successfully in', outDir);
