"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { NAV_ITEMS, SCHOOL_INFO } from "@/constants";
import SocialLinks from "@/components/common/SocialIcons";
import { isAdminAuthenticated, clearAdminSession } from "@/utils/adminStorage";

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);
  const [mobileExpanded, setMobileExpanded] = useState<Record<string, boolean>>({});
  const pathname = usePathname();
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    setIsAdmin(isAdminAuthenticated());
  }, [pathname]);

  const handleAdminLogout = () => {
    clearAdminSession();
    setIsAdmin(false);
    window.location.href = "/login";
  };

  // Close mobile menu on route change
  useEffect(() => {
    setMobileMenuOpen(false);
    setOpenDropdown(null);
  }, [pathname]);

  // Lock body scroll when mobile menu is open
  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "unset";
    }
    return () => {
      document.body.style.overflow = "unset";
    };
  }, [mobileMenuOpen]);

  const toggleMobileSubmenu = (label: string) => {
    setMobileExpanded((prev) => ({
      ...prev,
      [label]: !prev[label],
    }));
  };

  return (
    <>
      {/* ─── BRANDING ROW (Crest + School Name + Call Us + Login/Logout) ─── */}
      <div className="bg-white border-b border-slate-100 py-3 px-3 sm:px-4 lg:px-6">
        <div className="max-w-[1440px] mx-auto flex items-center justify-between gap-4">
          
          {/* Left: School Crest & Stately Title */}
          <Link href="/" className="flex items-center gap-2.5 sm:gap-3 group focus:outline-none">
            <div className="relative h-12 w-10 sm:h-14 sm:w-12 md:h-16 md:w-14 flex-shrink-0 transition-transform group-hover:scale-105">
              <Image
                src="/images/logo/allsaints-crest-v2.png"
                alt="All Saints Public School Crest"
                fill
                className="object-contain"
                sizes="(max-width: 640px) 48px, 60px"
                priority
                unoptimized
              />
            </div>
            <div className="flex flex-col">
              <span className="font-serif font-black text-sm sm:text-base md:text-xl lg:text-[21px] text-[#092F78] leading-tight uppercase tracking-tight">
                ALL SAINTS PUBLIC SCHOOL, ADOOR
              </span>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="text-xs sm:text-sm font-sans font-bold text-slate-700 tracking-wide">
                  (CBSE - 930501)
                </span>
                <span className="hidden sm:inline-block w-1.5 h-1.5 rounded-full bg-[#FFB900]" />
                <span className="hidden sm:inline-block text-xs font-serif font-bold text-[#FFB900] uppercase tracking-wider">
                  To Create Creators
                </span>
              </div>
            </div>
          </Link>

          {/* Right: Call Us + Login/Logout Buttons (Desktop) */}
          <div className="hidden lg:flex items-center gap-5 flex-shrink-0">
            {/* Call Us Block */}
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-full bg-[#D9EEFF] text-[#0875C9] border border-[#BFE3FF] flex items-center justify-center shadow-2xs flex-shrink-0">
                <svg
                  className="w-5 h-5 text-[#0875C9] fill-current"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                >
                  <path d="M20.01 15.38c-1.23 0-2.42-.2-3.53-.56a.977.977 0 00-1.01.24l-2.2 2.2a15.053 15.053 0 01-6.59-6.59l2.2-2.21a.96.96 0 00.25-1A11.36 11.36 0 018.5 4c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1 0 9.39 7.61 17 17 17 .55 0 1-.45 1-1v-3.5c0-.55-.45-1-1-1z" />
                </svg>
              </div>
              <div className="flex flex-col">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider leading-none">
                  Call Us
                </span>
                <span className="text-xs font-sans font-bold text-[#092F78] mt-0.5">
                  {SCHOOL_INFO.phone[0]}, {SCHOOL_INFO.phone[1]}
                </span>
              </div>
            </div>

            {/* Pill Login / Admin Session Buttons */}
            {isAdmin ? (
              <div className="flex items-center gap-2">
                <Link
                  href="/admin/dashboard"
                  className="bg-[#092F78] hover:bg-[#0875C9] text-white px-4 py-2 rounded-full text-xs font-serif font-bold uppercase tracking-wider shadow-sm transition-all whitespace-nowrap flex items-center gap-1.5 cursor-pointer"
                >
                  <span>🛡️ Dashboard</span>
                </Link>
                <button
                  type="button"
                  onClick={handleAdminLogout}
                  className="bg-red-600 hover:bg-red-700 text-white px-3.5 py-2 rounded-full text-xs font-serif font-bold uppercase tracking-wider shadow-sm transition-all whitespace-nowrap flex items-center gap-1.5 cursor-pointer"
                  title="Logout Administrator Session"
                >
                  <span>🚪 Logout</span>
                </button>
              </div>
            ) : (
              <Link
                href="/login"
                className="bg-[#0875C9] hover:bg-[#0066B5] text-white px-5 sm:px-6 py-2 rounded-full text-xs font-serif font-bold uppercase tracking-wider shadow-sm hover:shadow-md transition-all whitespace-nowrap cursor-pointer flex items-center gap-2 group"
              >
                <svg
                  className="w-4 h-4 text-white fill-current"
                  viewBox="0 0 20 20"
                  aria-hidden="true"
                >
                  <path
                    fillRule="evenodd"
                    d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z"
                    clipRule="evenodd"
                  />
                </svg>
                <span>Login</span>
              </Link>
            )}
          </div>

          {/* Mobile Quick Action Controls (< lg screens) */}
          <div className="flex items-center gap-2 lg:hidden">
            {isAdmin ? (
              <div className="flex items-center gap-1.5">
                <Link
                  href="/admin/dashboard"
                  className="bg-[#092F78] text-white px-2.5 py-1.5 rounded-full text-[11px] font-bold font-serif shadow-xs"
                >
                  Admin
                </Link>
                <button
                  type="button"
                  onClick={handleAdminLogout}
                  className="bg-red-600 hover:bg-red-700 text-white px-2.5 py-1.5 rounded-full text-[11px] font-bold font-serif shadow-xs cursor-pointer"
                >
                  Logout
                </button>
              </div>
            ) : (
              <Link
                href="/login"
                className="bg-[#0875C9] hover:bg-[#0066B5] text-white px-3.5 py-1.5 rounded-full text-xs font-bold font-serif shadow-xs flex items-center gap-1.5"
              >
                <svg
                  className="w-3.5 h-3.5 text-white fill-current"
                  viewBox="0 0 20 20"
                  aria-hidden="true"
                >
                  <path
                    fillRule="evenodd"
                    d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z"
                    clipRule="evenodd"
                  />
                </svg>
                <span>Login</span>
              </Link>
            )}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-1.5 text-slate-700 hover:text-[#0875C9] rounded-lg hover:bg-slate-100 transition-colors focus:outline-none"
              aria-label="Toggle Navigation Menu"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                {mobileMenuOpen ? (
                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
                )}
              </svg>
            </button>
          </div>

        </div>
      </div>

      {/* ─── 4. DEDICATED FULL-WIDTH NAVIGATION BAR (DESKTOP + MOBILE) ─── */}
      <header className="sticky top-0 z-50 w-full bg-white border-b border-[#D8EAF8] shadow-xs transition-all">
        <div className="max-w-[1440px] mx-auto px-3 sm:px-4 lg:px-6">
          
          {/* 4A. Desktop Navigation Row (>= lg screens) */}
          <nav className="hidden lg:flex items-center justify-between w-full font-sans py-1">
            <div className="flex items-center gap-0.5 xl:gap-1 2xl:gap-1.5 flex-nowrap w-full justify-between">
              {NAV_ITEMS.map((item) => {
                const hasChildren = item.children && item.children.length > 0;
                const isHome = item.href === "/" && pathname === "/";
                const isActive =
                  !isHome &&
                  (pathname === item.href ||
                    (hasChildren && item.children?.some((c) => pathname.startsWith(c.href))));
                const isDropdownOpen = openDropdown === item.label;

                // Home Link
                if (item.href === "/") {
                  return (
                    <Link
                      key={item.label}
                      href="/"
                      className={`px-4 py-2 rounded-xl text-[14px] xl:text-[14.5px] 2xl:text-[15px] font-sans font-bold transition-all whitespace-nowrap flex-shrink-0 ${
                        pathname === "/"
                          ? "text-[#092F78] bg-[#D9EEFF] shadow-2xs"
                          : "text-slate-700 hover:text-[#0875C9] hover:bg-[#F4FAFF]"
                      }`}
                    >
                      Home
                    </Link>
                  );
                }

                // Dropdown Menu Links (About ASPS, Academics, Facilities, Documents)
                if (hasChildren) {
                  return (
                    <div
                      key={item.label}
                      className="relative flex-shrink-0"
                      onMouseEnter={() => setOpenDropdown(item.label)}
                      onMouseLeave={() => setOpenDropdown(null)}
                    >
                      <button
                        className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-[14px] xl:text-[14.5px] 2xl:text-[15px] font-semibold transition-colors focus:outline-none whitespace-nowrap flex-shrink-0 cursor-pointer ${
                          isActive
                            ? "text-[#092F78] font-bold bg-[#D9EEFF]"
                            : "text-slate-700 hover:text-[#0875C9] hover:bg-[#F4FAFF]"
                        }`}
                        aria-expanded={isDropdownOpen}
                      >
                        <span className="whitespace-nowrap">{item.label}</span>
                        <svg
                          className={`w-3.5 h-3.5 text-slate-400 transition-transform duration-200 flex-shrink-0 ${
                            isDropdownOpen ? "rotate-180 text-[#0875C9]" : ""
                          }`}
                          fill="none"
                          stroke="currentColor"
                          strokeWidth={2}
                          viewBox="0 0 24 24"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                        </svg>
                      </button>

                      {/* Dropdown Popup with Blue Top Accent */}
                      {isDropdownOpen && (
                        <div
                          className={`absolute top-full mt-0.5 min-w-[340px] w-max bg-white rounded-2xl shadow-xl border border-[#D8EAF8] border-t-2 border-t-[#0875C9] py-2 z-50 animate-in fade-in-50 duration-150 ${
                            item.label === "Documents" ? "right-0" : "left-0"
                          }`}
                        >
                          <div className="px-4 py-1 text-[11px] font-bold uppercase tracking-wider text-[#FFB900] font-serif border-b border-slate-100 mb-1">
                            {item.label}
                          </div>
                          {item.children?.map((child) => (
                            <Link
                              key={child.href}
                              href={child.href}
                              className={`block px-4 py-2 text-[14px] font-sans transition-colors whitespace-nowrap ${
                                pathname === child.href
                                    ? "bg-[#EAF6FF] text-[#092F78] font-bold"
                                    : "text-slate-700 hover:bg-[#F4FAFF] hover:text-[#0875C9]"
                              }`}
                            >
                              {child.label}
                            </Link>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                }

                // Simple Direct Link (Online Admission, Gallery, News, Complain, Contact Us)
                return (
                  <Link
                    key={item.label}
                    href={item.href}
                    className={`px-3 py-2 rounded-xl text-[14px] xl:text-[14.5px] 2xl:text-[15px] font-semibold transition-colors whitespace-nowrap flex-shrink-0 cursor-pointer ${
                      pathname === item.href
                        ? "text-[#092F78] font-bold bg-[#D9EEFF]"
                        : "text-slate-700 hover:text-[#0875C9] hover:bg-[#F4FAFF]"
                    }`}
                  >
                    <span className="whitespace-nowrap">{item.label}</span>
                  </Link>
                );
              })}
            </div>
          </nav>

          {/* 4B. Sticky Mobile Navigation Bar (< lg screens: Phones & Tablets) */}
          <div className="flex lg:hidden items-center justify-between py-2">
            <Link href="/" className="flex items-center gap-2 group">
              <div className="relative w-8 h-9 flex-shrink-0">
                <Image
                  src="/images/logo/allsaints-crest-v2.png"
                  alt="Crest"
                  fill
                  className="object-contain"
                  unoptimized
                />
              </div>
              <div className="flex flex-col">
                <span className="font-serif font-black text-xs sm:text-sm text-[#092F78] uppercase tracking-tight leading-tight">
                  All Saints Public School
                </span>
                <span className="text-[10px] text-slate-500 font-sans font-semibold">
                  Adoor (CBSE - 930501)
                </span>
              </div>
            </Link>

            <div className="flex items-center gap-2">
              <Link
                href="/admissions/apply"
                className="bg-[#FFB900] hover:bg-[#E0A300] text-slate-950 text-[11px] font-bold px-3 py-1.5 rounded-full uppercase tracking-wider shadow-xs whitespace-nowrap"
              >
                Apply
              </Link>
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-1.5 text-slate-700 hover:text-[#0875C9] rounded-xl hover:bg-slate-100 transition-colors focus:outline-none cursor-pointer"
                aria-label="Toggle Navigation Menu"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                  {mobileMenuOpen ? (
                    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                  ) : (
                    <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
                  )}
                </svg>
              </button>
            </div>
          </div>

        </div>
      </header>

      {/* ─── 5. RESPONSIVE MOBILE NAVIGATION DRAWER (All 10 Categories) ─── */}
      {mobileMenuOpen && (
        <div
          className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm lg:hidden transition-opacity duration-200"
          onClick={() => setMobileMenuOpen(false)}
        >
          <div
            className="fixed top-0 right-0 bottom-0 w-full max-w-sm sm:max-w-md bg-white shadow-2xl flex flex-col h-full z-[101] overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            
            {/* Drawer Header (Fixed at top) */}
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-[#0875C9] text-white flex-shrink-0">
              <div className="flex items-center gap-3">
                <div className="relative w-10 h-10 flex-shrink-0">
                  <Image
                    src="/images/logo/allsaints-crest-v2.png"
                    alt="Crest"
                    fill
                    className="object-contain"
                    unoptimized
                  />
                </div>
                <div>
                  <span className="font-serif font-black text-base tracking-tight block leading-tight">
                    All Saints Public School
                  </span>
                  <span className="text-xs text-[#BFE3FF] font-sans font-semibold">
                    Adoor (CBSE - 930501)
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                className="w-9 h-9 rounded-full bg-white/20 text-white flex items-center justify-center text-xl font-bold hover:bg-white hover:text-[#0875C9] transition-colors cursor-pointer"
                aria-label="Close menu"
              >
                ✕
              </button>
            </div>

            {/* Scrollable Content Area */}
            <div className="flex-1 overflow-y-auto overscroll-contain">

              {/* Quick Actions in Mobile Drawer */}
              <div className="p-4 bg-[#F4FAFF] border-b border-[#D8EAF8] flex gap-3">
                <Link
                  href="/admissions/apply"
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex-1 bg-[#FFB900] hover:bg-[#E0A300] text-slate-950 py-2.5 px-3 rounded-xl text-center text-xs font-serif font-bold uppercase tracking-wider shadow-xs"
                >
                  Online Admission
                </Link>
                {isAdmin ? (
                  <button
                    type="button"
                    onClick={() => {
                      setMobileMenuOpen(false);
                      handleAdminLogout();
                    }}
                    className="flex-1 bg-red-600 hover:bg-red-700 text-white py-2.5 px-3 rounded-xl text-center text-xs font-serif font-bold uppercase tracking-wider shadow-xs cursor-pointer"
                  >
                    Logout Admin
                  </button>
                ) : (
                  <Link
                    href="/login"
                    onClick={() => setMobileMenuOpen(false)}
                    className="flex-1 bg-[#0875C9] hover:bg-[#0066B5] text-white py-2.5 px-3 rounded-xl text-center text-xs font-serif font-bold uppercase tracking-wider shadow-xs"
                  >
                    Admin Login
                  </Link>
                )}
              </div>

              {/* Drawer Links Accordion */}
              <div className="p-4 space-y-1">
                {NAV_ITEMS.map((item) => {
                  const hasChildren = item.children && item.children.length > 0;
                  const isExpanded = mobileExpanded[item.label];

                  if (hasChildren) {
                    return (
                      <div key={item.label} className="border-b border-slate-100 pb-1">
                        <div className="w-full flex items-center justify-between">
                          <Link
                            href={item.href}
                            onClick={() => setMobileMenuOpen(false)}
                            className={`flex-1 py-3 px-2 text-[15.5px] font-sans font-bold transition-colors ${
                              pathname === item.href || (item.children?.some((c) => pathname.startsWith(c.href)))
                                ? "text-[#0875C9]"
                                : "text-slate-800 hover:text-[#0875C9]"
                            }`}
                          >
                            {item.label}
                          </Link>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleMobileSubmenu(item.label);
                            }}
                            className="p-3 text-slate-400 hover:text-[#0875C9] transition-colors cursor-pointer rounded-lg"
                            aria-label={`Toggle ${item.label} submenu`}
                          >
                            <svg
                              className={`w-4 h-4 transition-transform duration-200 ${
                                isExpanded ? "rotate-180 text-[#0875C9]" : ""
                              }`}
                              fill="none"
                              stroke="currentColor"
                              strokeWidth={2}
                              viewBox="0 0 24 24"
                            >
                              <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                            </svg>
                          </button>
                        </div>
                        {isExpanded && (
                          <div className="pl-2 pb-2 space-y-1 bg-[#EAF6FF] rounded-2xl p-2.5 mb-2">
                            {item.children?.map((child) => (
                              <Link
                                key={child.href}
                                href={child.href}
                                onClick={() => setMobileMenuOpen(false)}
                                className={`block py-2 px-3 text-[14px] font-sans rounded-xl transition-colors ${
                                  pathname === child.href
                                    ? "bg-white text-[#092F78] font-bold shadow-2xs"
                                    : "text-slate-700 hover:bg-white hover:text-[#0875C9] font-medium"
                                  }`}
                              >
                                {child.label}
                              </Link>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  }

                  return (
                    <Link
                      key={item.label}
                      href={item.href}
                      onClick={() => setMobileMenuOpen(false)}
                      className={`block py-3 px-2 text-[15.5px] font-sans font-bold border-b border-slate-100 rounded-xl transition-colors ${
                        pathname === item.href
                          ? "text-[#092F78] bg-[#D9EEFF]"
                          : "text-slate-800 hover:text-[#0875C9] hover:bg-[#F4FAFF]"
                      }`}
                    >
                      {item.label}
                    </Link>
                  );
                })}
              </div>

            </div>

            {/* Drawer Footer with Helplines and Social Media (Fixed at bottom) */}
            <div className="p-4 border-t border-[#D8EAF8] bg-[#F4FAFF] space-y-2.5 flex-shrink-0">
              <div>
                <span className="font-serif font-bold text-[#092F78] text-xs uppercase tracking-wider block mb-1.5">
                  Follow Us Online:
                </span>
                <SocialLinks variant="footer" />
              </div>

              <div className="text-xs text-slate-600 space-y-1">
                <span className="font-bold text-[#0875C9] block">Admissions &amp; Helplines:</span>
                <p className="flex items-center gap-1.5 flex-wrap">
                  <svg className="w-3.5 h-3.5 text-[#0875C9] fill-current flex-shrink-0" viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M20.01 15.38c-1.23 0-2.42-.2-3.53-.56a.977.977 0 00-1.01.24l-2.2 2.2a15.053 15.053 0 01-6.59-6.59l2.2-2.21a.96.96 0 00.25-1A11.36 11.36 0 018.5 4c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1 0 9.39 7.61 17 17 17 .55 0 1-.45 1-1v-3.5c0-.55-.45-1-1-1z" />
                  </svg>
                  <a href={`tel:${SCHOOL_INFO.phone[0]}`} className="hover:text-[#0875C9] hover:underline font-semibold">
                    {SCHOOL_INFO.phone[0]}
                  </a>
                  <span>,</span>
                  <a href={`tel:${SCHOOL_INFO.phone[1]}`} className="hover:text-[#0875C9] hover:underline font-semibold">
                    {SCHOOL_INFO.phone[1]}
                  </a>
                </p>
                <p className="flex items-center gap-1.5">
                  <span>✉️</span>
                  <a href={`mailto:${SCHOOL_INFO.email}`} className="hover:text-[#0875C9] hover:underline font-semibold">
                    {SCHOOL_INFO.email}
                  </a>
                </p>
              </div>
            </div>

          </div>
        </div>
      )}
    </>
  );
}
